﻿using UnityEngine;


namespace FPS_Kotikov_D
{
    public abstract class Weapons : BaseObjectScene
    {


        #region Fields

        // Функция для вызова выстрела, обязательна во всех дочерних классах
        public abstract void Fire();

        // Позиция, из которой будут вылетать снаряды
        [SerializeField] protected Transform _gun;
        // Сила выстрела                
        [SerializeField] protected float _force = 500;
        // Время задержки между выстрелами           
        [SerializeField] protected float _rechargeTime = 0.2f;

        // Флаг, разрешающий выстрел  
        protected bool _fire = true;

        #endregion


    }
}   