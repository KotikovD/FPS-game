﻿using UnityEngine;
using System.Collections;


namespace FPS_Kotikov_D
{
    /// <summary>
    /// Class determine machinegun behaviour
    /// </summary>
    public sealed class Gun : Weapons
{


        #region Methods

        public override void Fire()
        {
            //TODO
        }

        #endregion


    }
}