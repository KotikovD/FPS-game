﻿using UnityEngine;
using System.Collections.Generic;
using FPS_Kotikov_D.Controller;
// using FPS_Kotikov_D.Helper;     // Что это где вообще? Подключаем пространство имен, в котором находятся хэлперы


namespace FPS_Kotikov_D
{
    /// <summary>
    /// Start programm class
    /// </summary>
    public sealed class MainController : MonoBehaviour
    {

        #region Fields

        private GameObject _controllersGameObject;
        private InputController _inputController;
        private FlashlightController _flashlightController;
        private PlayerController _playerController;
      

        #endregion


        #region Properties

        public static MainController Instance { get; private set; }
       
        /// <summary>
        /// Get flashlight controller
        /// </summary>
        public FlashlightController GetFlashlightController
        {
            get { return _flashlightController; }
        }

        /// <summary>
        /// Get input controller
        /// </summary>
        public InputController GetInputController
        {
           get {  return _inputController; }
        }

        /// <summary>
        /// Get Player controller
        /// </summary>
        public PlayerController GetPlayerController
        {
            get { return _playerController; }
        }

        #endregion


        #region UnityMethods

        void Start()
        {
            Instance = this;
            _controllersGameObject = new GameObject { name = "Controllers" };
            _inputController = _controllersGameObject.AddComponent<InputController>();
            _flashlightController = _controllersGameObject.AddComponent<FlashlightController>();
            
        }

        #endregion


   }
}
