﻿using UnityEngine;


namespace FPS_Kotikov_D.Controller
{

    public class FlashlightController : BaseController
    {


        #region Fields

        private FlashlightModel _light;
        private FlashLightUI _flashLightUi;

        #endregion


        #region UnityMethods

        private void Awake()
        {
            Instantiate(Resources.Load("Flashlight", typeof(GameObject)));
            _light = GameObject.FindWithTag("Flashlight").GetComponent<FlashlightModel>();
            _flashLightUi = Object.FindObjectOfType<FlashLightUI>();
            _flashLightUi.Text = _light.BatteryChargeCurrent;
        }

        public void Start()
        {
           
            SetActiveFlashlight(false);
        }

        public void Update()
        {
            CheckBattery();
            if (!IsActive) return;                            
            _light.LightRotation();
            
        }

        #endregion


        #region LifecycleMethods

        private void CheckBattery()
        {
            

            if (IsActive && _light.EditBatteryCharge())
            {
                _light.EditBatteryCharge();
            }
            else
            {
                _light.Switch(false);
            }

            if (!IsActive)
                _light.ChargingBattery();

            _flashLightUi.Text = _light.BatteryChargeCurrent;
        }



        #endregion


        #region Methods

        private void SetActiveFlashlight(bool value)
        {
            _light.Switch(value);   
        }

        public override void On()
        {
            if (IsActive) return;     
            base.On();
            SetActiveFlashlight(true);
        }

        public override void Off()
        {
            if (!IsActive) return;   
            base.Off();
            SetActiveFlashlight(false);
        }

        #endregion


    }
}