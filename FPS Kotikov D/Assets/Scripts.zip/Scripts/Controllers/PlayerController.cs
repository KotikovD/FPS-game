﻿namespace FPS_Kotikov_D
{

	public class PlayerController : BaseController
	{
        private readonly IMotor _motor;

        public PlayerController(IMotor motor)
        {
            _motor = motor;
        }

        public void Update()
        {
            if (!IsActive) { return; }
            _motor.Move();
        }
    }

}