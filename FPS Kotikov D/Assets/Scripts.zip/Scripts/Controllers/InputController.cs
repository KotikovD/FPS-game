﻿using UnityEngine;


namespace FPS_Kotikov_D.Controller
{
    /// <summary>
    /// Read all inputs in programm 
    /// </summary>
    public class InputController : BaseController
    {


        #region Fields

        private bool _isActiveFlashlight = false;

        #endregion


        #region UnityMethods

        public void Update()
        {
            if (Input.GetKeyDown(KeyCode.F))
            { 
                _isActiveFlashlight = !_isActiveFlashlight;
                if (_isActiveFlashlight)
                {
                    MainController.Instance.GetFlashlightController.On();
                }
                else
                {
                    MainController.Instance.GetFlashlightController.Off();
                }
            }
        }

        #endregion


    }
}