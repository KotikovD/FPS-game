﻿namespace FPS_Kotikov_D
{
	public interface IMotor
	{
		void Move();
	}
}